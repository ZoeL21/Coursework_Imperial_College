./start 6
sleep 5
./consumer 1 &
./consumer 2 &
./consumer 3 &
