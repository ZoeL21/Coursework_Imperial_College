./start 5
sleep 1
./producer 1 20 &
./consumer 1 &
./consumer 2 &
./consumer 3 &
./consumer 4 &
./consumer 5 &
./consumer 6 &
./consumer 7 &
./consumer 8 &
./consumer 9 &
./consumer 10 &
