./start 10
sleep 10
./producer 1 5 &
./producer 2 2 &
