./start 5
sleep 1
./producer 1 6 &
./producer 2 1 &
